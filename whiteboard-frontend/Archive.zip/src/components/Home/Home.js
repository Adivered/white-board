import React, { useEffect, useState } from 'react';
import Header from '../Header/Header';
import './Home.css';

const Home = () => {
  const [user, setUser] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    console.log("Token: ", token);
    if (token) {
      fetch('http://localhost:5000/token', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      })
        .then((res) => res.json().then(data => ({ status: res.status, body: data })))
        .then(({ status, body }) => {
          if (status === 200) {
            console.log("Status: ",status);
            setUser(body.user);
          } else {
            console.log("err: ");
            setErrorMsg(body.msg);
          }
        })
        .catch((err) => {
          console.error('Error fetching user data:', err);
          setErrorMsg('An error occurred while fetching user data');
        });
    }
  }, []);

  return (
    <div>
      <Header />
      <main>
        <section className="intro">
          <h1>Welcome to the Whiteboard App</h1>
          <p>
            Our Whiteboard app allows you to collaborate in real-time with your team. 
            Draw, write, and brainstorm ideas seamlessly on a digital canvas.
          </p>
          {user ? (
            <div>
              <h2>Hello, {user.name}</h2>
              <p>Email: {user.email}</p>
            </div>
          ) : (
            <p>{errorMsg || 'Loading user data...'}</p>
          )}
        </section>
      </main>
    </div>
  );
};

export default Home;